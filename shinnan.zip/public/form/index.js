export default function list ( req, res ) {
    return res.send();
}